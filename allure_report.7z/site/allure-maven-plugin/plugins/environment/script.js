/*global angular*/
(function() {
    "use strict";
    angular.module('allure.environment', []);
})();
